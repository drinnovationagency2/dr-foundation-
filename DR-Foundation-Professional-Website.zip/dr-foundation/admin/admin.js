(() => {
  const config = window.DR_FOUNDATION_CONFIG || {};
  const $ = id => document.getElementById(id);
  const form = $("loginForm");
  const message = $("adminMessage");
  const dashboard = $("dashboard");
  let client = null;

  function showMessage(text, isError = false) {
    message.textContent = text;
    message.classList.toggle("error", isError);
  }
  function setupClient() {
    if (!config.supabaseUrl || !config.supabaseAnonKey) {
      showMessage("Setup required: js/config.js में Supabase URL और public anon/publishable key सेट करें। अभी कोई login attempt नहीं किया गया।");
      return false;
    }
    if (!window.supabase || !window.supabase.createClient) {
      showMessage("Supabase client लोड नहीं हुआ। इंटरनेट कनेक्शन जाँचें और पेज reload करें।", true);
      return false;
    }
    client = window.supabase.createClient(config.supabaseUrl, config.supabaseAnonKey);
    return true;
  }
  async function loadDashboard(user) {
    $("signedInAs").textContent = user.email || user.id;
    dashboard.hidden = false;
    try {
      const { data: projects, error: projectError } = await client
        .from("projects").select("id,title,status,updated_at").order("updated_at", { ascending: false }).limit(10);
      if (projectError) throw projectError;
      $("projectCount").textContent = (projects || []).length;
      $("projectRows").innerHTML = "";
      (projects || []).forEach(project => {
        const tr = document.createElement("tr");
        [project.title, project.status, project.updated_at ? new Date(project.updated_at).toLocaleDateString() : "—"].forEach(value => {
          const td = document.createElement("td");
          td.textContent = value || "—";
          tr.appendChild(td);
        });
        $("projectRows").appendChild(tr);
      });
      if (!projects || projects.length === 0) $("projectRows").innerHTML = '<tr><td colspan="3">No projects yet</td></tr>';
      const { count, error: enquiryError } = await client.from("enquiries").select("id", { count: "exact", head: true });
      if (enquiryError) throw enquiryError;
      $("enquiryCount").textContent = String(count ?? 0);
      showMessage("Signed in. Data access is controlled by database policies.");
    } catch (err) {
      showMessage("डेटा लोड नहीं हुआ। SQL schema, admin role, RLS policies और नेटवर्क जाँचें। " + (err.message || ""), true);
    }
  }
  form.addEventListener("submit", async event => {
    event.preventDefault();
    if (!setupClient()) return;
    const button = $("loginButton");
    button.disabled = true;
    showMessage("Signing in…");
    try {
      const { data, error } = await client.auth.signInWithPassword({
        email: $("email").value.trim(),
        password: $("password").value
      });
      if (error) throw error;
      if (data.user) await loadDashboard(data.user);
    } catch (err) {
      showMessage("लॉगिन असफल। ईमेल/पासवर्ड, Supabase Auth configuration और खाते की पुष्टि जाँचें। " + (err.message || ""), true);
    } finally {
      button.disabled = false;
    }
  });
  $("logoutButton").addEventListener("click", async () => {
    if (client) await client.auth.signOut();
    dashboard.hidden = true;
    showMessage("आप साइन आउट हो गए हैं।");
  });
  window.addEventListener("load", () => {
    if (!config.supabaseUrl || !config.supabaseAnonKey) {
      showMessage("Setup required: js/config.js में Supabase URL और public anon/publishable key सेट करें, फिर database/schema.sql चलाएँ।");
    } else {
      setupClient();
      if (client) client.auth.getSession().then(({ data }) => {
        if (data.session?.user) loadDashboard(data.session.user);
      });
    }
  });
})();
