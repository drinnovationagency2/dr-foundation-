(() => {
  const config = window.DR_FOUNDATION_CONFIG || {};
  const $ = (selector, root = document) => root.querySelector(selector);
  const menu = $("#mainNav");
  const menuToggle = $("#menuToggle");
  const langToggle = $("#languageToggle");
  const year = $("#year");
  if (year) year.textContent = new Date().getFullYear();

  const translations = {
    hi: {
      skip:"मुख्य सामग्री पर जाएँ",brandTag:"शिक्षा • नवाचार • जनसेवा",navAbout:"हमारे बारे में",navPrograms:"कार्यक्रम",navProjects:"प्रोजेक्ट",navJoin:"जुड़ें",navContact:"संपर्क",navAdmin:"Admin",
      eyebrow:"एक बेहतर भविष्य के लिए साथ",heroTitle:'ज्ञान, नवाचार और सेवा से <span>सकारात्मक बदलाव</span>',heroDesc:"DR Foundation शिक्षा, तकनीकी नवाचार, सामाजिक कल्याण, स्वास्थ्य-जागरूकता और कौशल विकास के माध्यम से समुदायों के साथ मिलकर काम करने का लक्ष्य रखता है।",explorePrograms:"हमारे कार्यक्रम देखें ↗",joinMovement:"हमसे जुड़ें",heroNote:"हर पहल में पारदर्शिता, सीखना और सामुदायिक भागीदारी।",coreCaption:"Ideas into impact",artEducation:"शिक्षा",artInnovation:"नवाचार",artCommunity:"समुदाय",focusAreas:"मुख्य कार्यक्षेत्र",sharedGoal:"साझा लक्ष्य — सकारात्मक बदलाव",ideas:"सीखने और नवाचार के अवसर",
      aboutKicker:"हम कौन हैं",aboutTitle:"अवसरों को सक्षम बनाने वाला एक साझा मंच",aboutText:"DR Foundation का उद्देश्य लोगों को सीखने, नए विचार विकसित करने और समुदाय के लिए उपयोगी पहल में भाग लेने के अवसर देना है। हम कार्यक्रमों और साझेदारियों के माध्यम से व्यावहारिक, समावेशी और जिम्मेदार प्रभाव बनाने की दिशा में काम करना चाहते हैं।",principle1:"समावेशिता",principle1d:"लोगों और समुदायों को साथ लेकर चलना",principle2:"नवाचार",principle2d:"सीखना, प्रयोग करना और सुधारना",principle3:"पारदर्शिता",principle3d:"जिम्मेदार और स्पष्ट कार्यप्रणाली",
      programKicker:"हमारी प्राथमिकताएँ",programTitle:"कार्यक्रम और कार्यक्षेत्र",programIntro:"स्थानीय जरूरतों के अनुसार सीखने, भागीदारी और उपयोगी परियोजनाओं को बढ़ावा देने की दिशा।",p1Title:"शिक्षा",p1Text:"शैक्षिक अवसर, डिजिटल साक्षरता, सीखने की सामग्री और विद्यार्थियों के लिए कार्यक्रम।",p2Title:"तकनीक और नवाचार",p2Text:"तकनीकी विचार, उपयोगी प्रोटोटाइप, डिजिटल समाधान और नवाचार परियोजनाएँ।",p3Title:"सामाजिक कल्याण",p3Text:"समुदाय-आधारित पहल, स्वयंसेवा और जरूरतों के अनुसार सहायता गतिविधियाँ।",p4Title:"स्वास्थ्य और पर्यावरण",p4Text:"स्वास्थ्य-जागरूकता, स्वच्छता, पर्यावरण संरक्षण और सामुदायिक अभियान।",p5Title:"कौशल विकास",p5Text:"डिजिटल कौशल, व्यावहारिक प्रशिक्षण, कार्यशालाएँ और रोजगार-तैयारी।",learnJoin:"भाग लेने के बारे में जानें ↗",
      projectKicker:"काम को आगे बढ़ाएँ",projectTitle:"प्रोजेक्ट और पहल",projectIntro:"यहाँ संस्था की सत्यापित, वास्तविक गतिविधियों और परियोजनाओं का विवरण प्रकाशित किया जाएगा।",projectEmptyTitle:"पहली परियोजना जल्द जोड़ें",projectEmptyText:"वास्तविक परियोजना शुरू होने पर उसका उद्देश्य, गतिविधियाँ, प्रगति और परिणाम यहाँ प्रकाशित करें। अभी कोई अप्रमाणित उपलब्धि या आँकड़ा प्रदर्शित नहीं किया गया है।",suggestProject:"प्रोजेक्ट सुझाएँ",
      joinKicker:"साथ मिलकर आगे बढ़ें",joinTitle:"आपका विचार अगली पहल बन सकता है।",joinText:"स्वयंसेवक, विद्यार्थी, प्रशिक्षक और सहयोगी के रूप में अपनी रुचि साझा करें। टीम आपसे संपर्क करने के लिए आवेदन प्राप्त होने की व्यवस्था सक्रिय होने के बाद ही जानकारी देख पाएगी।",joinB1:"अपनी रुचि साझा करें",joinB2:"कार्यक्रमों में भाग लेने का अवसर",joinB3:"समुदाय के लिए मिलकर काम करें",joinFormTitle:"रुचि दर्ज करें",formIntro:"सभी आवश्यक फ़ील्ड भरें। यह फॉर्म सक्रिय करने के लिए config.js में form endpoint सेट करना होगा।",labelName:"पूरा नाम",labelEmail:"ईमेल",labelInterest:"रुचि का क्षेत्र",selectOption:"एक विकल्प चुनें",labelMessage:"संदेश (वैकल्पिक)",consent:"मैं अपनी जानकारी इस अनुरोध के उत्तर के लिए उपयोग किए जाने की सहमति देता/देती हूँ।",submitInterest:"रुचि भेजें",
      contactKicker:"संपर्क",contactTitle:"आइए, बातचीत शुरू करें।",contactText:"कार्यक्रम, साझेदारी या सामान्य पूछताछ के लिए संदेश भेजें। नीचे दिए गए ईमेल को लॉन्च से पहले अपने सत्यापित आधिकारिक संपर्क से मिलाएँ।",emailLabel:"ईमेल",onlineLabel:"ऑनलाइन",sendEnquiry:"पूछताछ भेजें ↗",contactNote:"यह प्रारंभिक टेम्पलेट है। प्रकाशित करने से पहले संस्था का सही संपर्क और कानूनी विवरण भरें।",footerText:"सीखने, नवाचार और सामुदायिक भागीदारी से बेहतर भविष्य की ओर।",privacy:"गोपनीयता",footerDisclaimer:"सभी कार्यक्रमों और दावों को प्रकाशित करने से पहले सत्यापित करें.",
      privacyTitle:"गोपनीयता नीति",privacyIntro:"यह एक प्रारंभिक नमूना है। अपनी वास्तविक डेटा-प्रक्रिया, संस्था की जानकारी और लागू कानून के अनुसार प्रकाशित करने से पहले इसे संशोधित करें।",privacyCollectTitle:"कौन-सी जानकारी ली जा सकती है?",privacyCollect:"सक्रिय किए जाने पर आवेदन फॉर्म नाम, ईमेल, रुचि और उपयोगकर्ता द्वारा लिखे गए संदेश को ले सकता है। स्वास्थ्य या पहचान संबंधी संवेदनशील जानकारी इस फॉर्म में न भेजें।",privacyUseTitle:"जानकारी का उपयोग",privacyUse:"जानकारी का उपयोग केवल अनुरोध का उत्तर देने और संबंधित कार्यक्रम के समन्वय के लिए करें। आवश्यक से अधिक डेटा न लें और पहुँच सीमित रखें।",privacyStorageTitle:"भंडारण और सुरक्षा",privacyStorage:"फॉर्म सबमिशन तभी भेजे जाएँगे जब वास्तविक सेवा endpoint कॉन्फ़िगर होगा। सेवा प्रदाता की नीति, डेटा-रखने की अवधि और पहुँच नियंत्रण की जाँच करें।",privacyContactTitle:"संपर्क",privacyContact:"गोपनीयता संबंधी प्रश्नों के लिए संस्था के सत्यापित आधिकारिक संपर्क का उपयोग करें।",backHome:"होम पेज पर लौटें"
    },
    en: {
      skip:"Skip to main content",brandTag:"Education • Innovation • Social Impact",navAbout:"About",navPrograms:"Programs",navProjects:"Projects",navJoin:"Join Us",navContact:"Contact",navAdmin:"Admin",
      eyebrow:"Together for a better future",heroTitle:'Creating <span>positive change</span> through knowledge, innovation and service',heroDesc:"DR Foundation aims to work alongside communities through education, technology innovation, social welfare, health awareness and skill development.",explorePrograms:"Explore our programs ↗",joinMovement:"Join us",heroNote:"Transparency, learning and community participation in every initiative.",coreCaption:"Ideas into impact",artEducation:"Education",artInnovation:"Innovation",artCommunity:"Community",focusAreas:"Core focus areas",sharedGoal:"One shared goal — positive change",ideas:"Opportunities to learn and innovate",
      aboutKicker:"Who we are",aboutTitle:"A shared platform that enables opportunity",aboutText:"DR Foundation aims to create opportunities for people to learn, develop new ideas and take part in useful community initiatives. Through programs and partnerships, we aspire to create practical, inclusive and responsible impact.",principle1:"Inclusion",principle1d:"Bringing people and communities together",principle2:"Innovation",principle2d:"Learn, experiment and improve",principle3:"Transparency",principle3d:"Responsible and clear practices",
      programKicker:"Our priorities",programTitle:"Programs and focus areas",programIntro:"Encouraging learning, participation and useful projects shaped by local needs.",p1Title:"Education",p1Text:"Learning opportunities, digital literacy, learning resources and student programs.",p2Title:"Technology & Innovation",p2Text:"Technology ideas, useful prototypes, digital solutions and innovation projects.",p3Title:"Social Welfare",p3Text:"Community initiatives, volunteering and support activities based on local needs.",p4Title:"Health & Environment",p4Text:"Health awareness, sanitation, environmental protection and community campaigns.",p5Title:"Skill Development",p5Text:"Digital skills, practical training, workshops and employment readiness.",learnJoin:"Explore how to participate ↗",
      projectKicker:"Move ideas forward",projectTitle:"Projects and initiatives",projectIntro:"Verified information about real activities and projects will be published here.",projectEmptyTitle:"Add the first project soon",projectEmptyText:"When a real project begins, publish its purpose, activities, progress and outcomes here. No unverified achievements or statistics are shown at this time.",suggestProject:"Suggest a project",
      joinKicker:"Move forward together",joinTitle:"Your idea could become the next initiative.",joinText:"Share your interest as a volunteer, student, trainer or collaborator. The team can receive your information only after a real submission service has been activated.",joinB1:"Share your interests",joinB2:"Explore opportunities to participate",joinB3:"Work together for the community",joinFormTitle:"Register your interest",formIntro:"Complete required fields. Set a real form endpoint in config.js to activate submissions.",labelName:"Full name",labelEmail:"Email",labelInterest:"Area of interest",selectOption:"Choose an option",labelMessage:"Message (optional)",consent:"I consent to using my information to respond to this enquiry.",submitInterest:"Submit interest",
      contactKicker:"Contact",contactTitle:"Let’s start a conversation.",contactText:"Contact us about programs, partnerships or general enquiries. Verify the email address below before launch.",emailLabel:"Email",onlineLabel:"Online",sendEnquiry:"Send an enquiry ↗",contactNote:"This is a starter template. Add verified contact and legal details before publishing.",footerText:"Towards a better future through learning, innovation and community participation.",privacy:"Privacy",footerDisclaimer:"Verify all programs and claims before publishing.",
      privacyTitle:"Privacy Policy",privacyIntro:"This is a starter template. Revise it to reflect your actual data practices, organization details and applicable law before publishing.",privacyCollectTitle:"What information may be collected?",privacyCollect:"Once activated, the application form may collect a name, email, area of interest and message. Do not submit sensitive health or identity information through this form.",privacyUseTitle:"How information is used",privacyUse:"Use information only to respond to enquiries and coordinate relevant programs. Avoid collecting more data than necessary and restrict access.",privacyStorageTitle:"Storage and security",privacyStorage:"Form submissions are sent only after a real service endpoint is configured. Review the provider's policy, retention period and access controls.",privacyContactTitle:"Contact",privacyContact:"Use the organization's verified official contact for privacy questions.",backHome:"Return to homepage"
    }
  };
  let currentLang = localStorage.getItem("drFoundationLang") || "hi";
  if (!translations[currentLang]) currentLang = "hi";

  function applyLanguage(lang) {
    currentLang = lang;
    document.documentElement.lang = lang;
    document.querySelectorAll("[data-i18n]").forEach(el => {
      const key = el.getAttribute("data-i18n");
      if (translations[lang][key]) el.innerHTML = translations[lang][key];
    });
    if (langToggle) langToggle.textContent = lang === "hi" ? "EN" : "हिं";
    localStorage.setItem("drFoundationLang", lang);
  }
  if (langToggle) langToggle.addEventListener("click", () => applyLanguage(currentLang === "hi" ? "en" : "hi"));
  applyLanguage(currentLang);

  if (menuToggle && menu) {
    menuToggle.addEventListener("click", () => {
      const isOpen = menu.classList.toggle("open");
      menuToggle.setAttribute("aria-expanded", String(isOpen));
      menuToggle.textContent = isOpen ? "×" : "☰";
    });
    menu.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
      menu.classList.remove("open");
      menuToggle.setAttribute("aria-expanded", "false");
      menuToggle.textContent = "☰";
    }));
  }

  const email = config.contactEmail || "contact@drfoundation.example";
  const emailEl = $("#contactEmail");
  if (emailEl) { emailEl.textContent = email; emailEl.href = "mailto:" + email; }
  const websiteLink = $("#websiteLink");
  if (websiteLink) { websiteLink.href = location.origin + location.pathname; }

  document.querySelectorAll("form[data-form-kind]").forEach(form => {
    form.addEventListener("submit", async event => {
      event.preventDefault();
      const status = form.querySelector(".form-status");
      const endpoint = (config.formEndpoint || "").trim();
      if (!endpoint || !/^https:\/\/.+/.test(endpoint)) {
        status.textContent = currentLang === "hi"
          ? "फॉर्म अभी सक्रिय नहीं है: js/config.js में वास्तविक Formspree या अन्य सुरक्षित form endpoint जोड़ें। अभी कोई डेटा भेजा या सहेजा नहीं गया।"
          : "Form is not active yet. Add a real Formspree or other secure form endpoint in js/config.js. No data has been sent or saved.";
        status.classList.add("error");
        return;
      }
      const submit = form.querySelector('button[type="submit"]');
      submit.disabled = true;
      status.textContent = currentLang === "hi" ? "भेजा जा रहा है…" : "Submitting…";
      try {
        const response = await fetch(endpoint, {
          method: "POST",
          body: new FormData(form),
          headers: { "Accept": "application/json" }
        });
        if (!response.ok) throw new Error("Submission failed");
        status.textContent = currentLang === "hi" ? "धन्यवाद! आपका आवेदन भेज दिया गया है।" : "Thank you! Your submission has been sent.";
        status.classList.remove("error");
        form.reset();
      } catch (error) {
        status.textContent = currentLang === "hi" ? "आवेदन नहीं भेजा जा सका। कनेक्शन और form endpoint जाँचें।" : "Submission failed. Check your connection and form endpoint.";
        status.classList.add("error");
      } finally {
        submit.disabled = false;
      }
    });
  });
})();
