/*
 DR Foundation public configuration.
 Do not put passwords, service-role keys, private API keys, or secrets in this file.
 Public Supabase URL + anon/publishable key can be used with strict RLS policies.
*/
window.DR_FOUNDATION_CONFIG = {
  // Example: "https://YOUR-PROJECT.supabase.co"
  supabaseUrl: "",
  // Public anon/publishable key only. Never use the service_role key in browser code.
  supabaseAnonKey: "",
  // Form endpoint from your chosen form provider, e.g. Formspree endpoint.
  // Keep empty until you create and verify a real endpoint.
  formEndpoint: "",
  // Replace with the organization's verified contact email before publishing.
  contactEmail: "contact@drfoundation.example"
};
