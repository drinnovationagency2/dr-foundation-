-- DR Foundation starter schema for Supabase/Postgres.
-- Review and test in a non-production project first.
-- Do not place service_role keys in website JavaScript.
-- Admin role assignment must be performed by a trusted project owner in the Supabase SQL editor.
-- Never allow a user to assign their own role.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'member' check (role in ('member','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text unique,
  summary text,
  program_area text not null check (program_area in (
    'Education','Technology & Innovation','Social Welfare',
    'Health & Environment','Skill Development'
  )),
  status text not null default 'draft' check (status in ('draft','active','completed','archived')),
  is_published boolean not null default false,
  start_date date,
  end_date date,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.enquiries (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 100),
  email text not null check (char_length(email) <= 200),
  interest text not null check (interest in (
    'Education','Technology & Innovation','Social Welfare',
    'Health & Environment','Skill Development','Volunteering'
  )),
  message text check (message is null or char_length(message) <= 2000),
  status text not null default 'new' check (status in ('new','reviewing','responded','closed')),
  created_at timestamptz not null default now()
);

create index if not exists projects_published_idx on public.projects(is_published, updated_at desc);
create index if not exists enquiries_created_idx on public.enquiries(created_at desc);
create index if not exists enquiries_status_idx on public.enquiries(status);

alter table public.profiles enable row level security;
alter table public.projects enable row level security;
alter table public.enquiries enable row level security;

-- Admin authorization helper. Security definer avoids recursive profiles RLS checks.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;

revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

-- Profiles: user can read their own profile; only admins can read/manage all profiles.
drop policy if exists "profiles read self or admin" on public.profiles;
create policy "profiles read self or admin" on public.profiles
for select to authenticated
using (id = auth.uid() or public.is_admin());

drop policy if exists "profiles update admin only" on public.profiles;
create policy "profiles update admin only" on public.profiles
for update to authenticated
using (public.is_admin())
with check (public.is_admin());

-- Projects: public visitors can see only published projects; admins can manage all.
drop policy if exists "published projects readable publicly" on public.projects;
create policy "published projects readable publicly" on public.projects
for select to anon, authenticated
using (is_published = true or public.is_admin());

drop policy if exists "admins insert projects" on public.projects;
create policy "admins insert projects" on public.projects
for insert to authenticated
with check (public.is_admin());

drop policy if exists "admins update projects" on public.projects;
create policy "admins update projects" on public.projects
for update to authenticated
using (public.is_admin())
with check (public.is_admin());

drop policy if exists "admins delete projects" on public.projects;
create policy "admins delete projects" on public.projects
for delete to authenticated
using (public.is_admin());

-- Enquiries: public form may insert; only admins can read or manage.
drop policy if exists "public may submit enquiry" on public.enquiries;
create policy "public may submit enquiry" on public.enquiries
for insert to anon, authenticated
with check (
  char_length(name) between 1 and 100
  and char_length(email) <= 200
  and interest in ('Education','Technology & Innovation','Social Welfare','Health & Environment','Skill Development','Volunteering')
);

drop policy if exists "admins read enquiries" on public.enquiries;
create policy "admins read enquiries" on public.enquiries
for select to authenticated
using (public.is_admin());

drop policy if exists "admins update enquiries" on public.enquiries;
create policy "admins update enquiries" on public.enquiries
for update to authenticated
using (public.is_admin())
with check (public.is_admin());

drop policy if exists "admins delete enquiries" on public.enquiries;
create policy "admins delete enquiries" on public.enquiries
for delete to authenticated
using (public.is_admin());

-- Do not create an open profile insert policy. After creating the first Auth user,
-- copy that user's UUID from Authentication > Users, then run the following manually:
-- insert into public.profiles (id, full_name, role)
-- values ('REPLACE-WITH-AUTH-USER-UUID', 'Foundation Administrator', 'admin');
--
-- Optional updated_at trigger:
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists projects_set_updated_at on public.projects;
create trigger projects_set_updated_at
before update on public.projects
for each row execute function public.set_updated_at();
